import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { GetProductsService } from '../Service/get-products.service';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit {
 public getDatabyMonthDate:any;
  public dayWisesale = [];
  constructor(private getDataService:GetProductsService) { }
  public monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];
  
  ngOnInit(): void {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth();
    const noOfDays = new Date(currentYear, currentMonth+1, 0).getDate();
    for (var i = 0; i < noOfDays; i++) {
      this.barChartLabels.push(JSON.stringify(i + 1));
    }
   
    this.getDataService.getAllOrdersByMonthandDates(currentMonth+1,currentYear).subscribe(data =>{
      this.getDatabyMonthDate = data;
      console.log(this.getDatabyMonthDate);
      for(let da of this.getDatabyMonthDate){
        this.dayWisesale.push(JSON.stringify(da));
      }
    
      console.log(this.dayWisesale);
    })

  }

  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLabels: Label[] = [];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  barChartColors = [ {
    borderColor: 'black',
    backgroundColor: 'orange',
  },];
  
  barChartData: ChartDataSets[] = [
    { data: this.dayWisesale, label: 'Day Wise Sale ('+this.monthNames[new Date().getMonth()]+')' }
  ];


}
