import { Component, OnInit } from '@angular/core';
import { GetProductsService } from '../Service/get-products.service';
import { Location } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { SuccessOrderComponent } from '../success-order/success-order.component';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css', './testCss.css']
})
export class PlaceOrderComponent implements OnInit {

  public newOrderList = [];
  public getAllProducts: any;
  public is: any;
  public show = false;
  public totalAmt: any = 0;
  public amtGiven: any = 0;
  public clickplaceorder = false;
  constructor(private products: GetProductsService, private _location: Location, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.products.getAllProducts().subscribe(data => {
      this.getAllProducts = data;
    });
this.addAnotherItem();
  }

  back() {
    this._location.back();
  }

  keyupBoard(data) {
    if (data.length > 0) {
      this.show = true;
    } else {
      this.show = false;
      //this.a
    }
  }

  selectProduct(prod, index) {
    console.log(prod);
    this.show = false;
    this.newOrderList[index]['productName'] = prod['productName'];
    this.newOrderList[index]['productId'] = prod['productId'];
    this.newOrderList[index]['perPeice'] = prod['productPrice'];
  }

  calculateAmt(prodName, quantity, index) {
    console.log(quantity, index);
    if (quantity != "" && quantity != undefined && prodName != "" && prodName != undefined) {
      this.newOrderList[index]['amount'] = parseInt(quantity) * parseInt(this.newOrderList[index]['perPeice']);
      console.log(this.newOrderList);
     this.calculateTotal();
    }

  }

  calculateTotal(){
    let amt = 0;
    for (let data of this.newOrderList) {
      amt = amt + data['amount'];
    }
    this.totalAmt = amt;
  }
  addAnotherItem() {
    this.newOrderList.push({
      "productId": "",
      "productName": "",
      "productQuantity": "",
      "perPeice": "",
      "amount": ""
    })
  }
  removeRow(index) {
    this.newOrderList.splice(index, 1);
    console.log(this.newOrderList);
    this.calculateTotal();
  }

  placeOrder() {
    console.log(this.newOrderList);
    if(this.newOrderList.length >= 0 && this.newOrderList[0]['productId'] != ""){
      const orderList = [];
    this.clickplaceorder = true;
      
    for (let data of this.newOrderList) {
      const list: Object = new Object();
      list['orderItemId'] = '';
      list['orderItemQuantity'] = data['productQuantity'];
      list['orderTotalPrice'] = data['amount'];
      const orders: Object = new Object();
      orders['orderId'] = '';
      list['order'] = orders;
      const products: Object = new Object();
      products['productId'] = data['productId'];
      list['prods'] = products;
      orderList.push(list);
    }


    const orders = {
      "orderId": "",
      "orderPlacedDate": "",
      "orderTotalAmt": this.totalAmt,
      "orderItems": orderList
    }
     this.products.placeOrder(orders).subscribe(data => {
       console.log(data);
      // const printContent = document.getElementById("invoice-POS");
      // const WindowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0');
      // //WindowPrt.document.write('<link rel="stylesheet" type="text/css" href="./place-order.component.css">');
      // WindowPrt.document.write(printContent.innerHTML);
      // WindowPrt.document.close();
      // WindowPrt.focus();
      // WindowPrt.print();
      // WindowPrt.close();
      this.dialog.open(SuccessOrderComponent,{
        data: 'Order has been placed successfully..!'
      });
      this.newOrderList = [];
      this.totalAmt = 0;
      this.amtGiven = 0;
      this.newOrderList.push(
        {
          "productId": "",
          "productName": "",
          "productQuantity": "",
          "perPeice": "",
          "amount": ""
        }
      )
      this.clickplaceorder = false;
     });
    }else{
      alert("hi");
    }
  
  }
}
