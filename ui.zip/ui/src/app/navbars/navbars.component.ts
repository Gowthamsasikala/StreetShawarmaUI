import { Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { HomeComponent } from '../home/home.component';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-navbars',
  templateUrl: './navbars.component.html',
  styleUrls: ['./navbars.component.css']
})
export class NavbarsComponent implements OnInit {

  public toggleBtn: Boolean = false;

  @ViewChildren(HomeComponent)
  public homeComponent:HomeComponent; 

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  openWindow() {
    this.toggleBtn = !this.toggleBtn;
  }

  close(){
    this.toggleBtn = false;
  }

  addProducts(){
   // console.log("hi");
    this.homeComponent.isaddProduct = true;
    this.route.navigateByUrl('/Home');
  }
}
