import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenOrderItemsComponent } from './open-order-items.component';

describe('OpenOrderItemsComponent', () => {
  let component: OpenOrderItemsComponent;
  let fixture: ComponentFixture<OpenOrderItemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpenOrderItemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenOrderItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
