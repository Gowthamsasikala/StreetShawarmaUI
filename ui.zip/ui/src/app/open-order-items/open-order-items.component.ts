import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-open-order-items',
  templateUrl: './open-order-items.component.html',
  styleUrls: ['./open-order-items.component.css']
})
export class OpenOrderItemsComponent implements OnInit {

  public orderItems:any;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    this.orderItems = this.data;
  }

}
