import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public isaddProduct;
  constructor(private route:Router) { }

  ngOnInit(): void {
    console.log(this.isaddProduct);
  }

  redirectTo(path:any){
    console.log(path);
    this.route.navigateByUrl(path);
  }

  addProduct(){
    this.isaddProduct = true;
  }
}
