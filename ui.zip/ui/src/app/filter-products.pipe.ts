import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterProducts'
})
export class FilterProductsPipe implements PipeTransform {

  transform(items: any[], filter: any): any {
    if (!items || !filter) {
        return items;
    }
   console.log(items);
   console.log(filter);
    return items.filter(item => item.productName.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
}

}
