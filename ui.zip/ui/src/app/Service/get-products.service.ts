import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GetProductsService {

  constructor(private http:HttpClient) { }

  getAllProducts(){
    return this.http.get('http://localhost:8086/Product/getProducts');
  }

  updateProduct(prod){
    return this.http.put("http://localhost:8086/Product/updateProducts",prod);
  }
 
  addProduct(prod){
 return this.http.post("http://localhost:8086/Product/addProduct",prod);
  }

  placeOrder(orders){
    return this.http.post("http://localhost:8086/Order/placeOrder",orders);
  }

  getOrderSummaryByDate(date){
    return this.http.get("http://localhost:8086/Order/getOrderByDate/"+date);
  }

  getOrdersByMonth(month){
    return this.http.get("http://localhost:8086/Order/getOrderByMonth/"+month);
  }

  getAllOrdersByMonth(){
    return this.http.get("http://localhost:8086/Order/getAllOrdersByMonth");
  }

  deleteOrderById(id){
    return this.http.delete("http://localhost:8086/Order/deleteByOrderId/"+id);
  }

  getAllOrdersByMonthandDates(month,year){
    return this.http.get("http://localhost:8086/Order/getAllOrdersByMonthAndDates/"+month+"/"+year);
  }
}
