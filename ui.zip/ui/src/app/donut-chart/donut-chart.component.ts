import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartType, RadialChartOptions } from 'chart.js';
import { MultiDataSet, Label,Color } from 'ng2-charts';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { GetProductsService } from '../Service/get-products.service';
import * as _moment from 'moment';
const moment = (_moment as any).default ? (_moment as any).default : _moment;
@Component({
  selector: 'app-donut-chart',
  templateUrl: './donut-chart.component.html',
  styleUrls: ['./donut-chart.component.css']
})
export class DonutChartComponent implements OnInit {

  public selectedDate: any;
  public dataSet: any;
  public countSet = [];
  public productSummarys = [];
  public label :any;
  public total:any;
  constructor(private getOrderService: GetProductsService) { }

  ngOnInit(): void {
    this.selectedDate = new Date();
    const format1 = "DD-MM-YYYY";
    const dateTime1 = moment(new Date()).format(format1);
    console.log(dateTime1);
    this.getOrderServices(dateTime1);
  }

  selectDate() {
    const format1 = "DD-MM-YYYY";
    const dateTime1 = moment(this.selectedDate).format(format1);
    this.getOrderServices(dateTime1);
  }

getOrderServices(date){
this.productSummarys = [];
this.total = 0;
  this.getOrderService.getOrderSummaryByDate(date).subscribe(data => {
    this.dataSet = data;
   // console.log(this.dataSet);
    const setRemove = new Set();
    for (let dat of this.dataSet) {
      for (let ord of dat['orderItems']) {
        setRemove.add(ord['prods']['productName']);
      }
    }
    let arr = Array.from(setRemove);
    arr.forEach(val => {
     
      let count = 0;
      let productPrice = 0;
      let perpeiceRate = 0;
      for (let dat of this.dataSet) {
        for (let ord of dat['orderItems']) {
          if(ord['prods']['productName'] == val){
            count = count + parseInt(ord['orderItemQuantity']);
            productPrice = productPrice + parseInt(ord['orderTotalPrice']);
            perpeiceRate = ord['prods']['productPrice'];
          }
        }
      }
      const obj = new Object();
      obj['ProductName'] = val;
      obj['Count'] = count;
      obj['ProductPrice'] = productPrice;
      obj['PerPeiceRate'] = perpeiceRate;
      this.productSummarys.push(obj);
     // console.log(this.productSummarys);
    });
      let totalAmt = 0;
    this.productSummarys.forEach(data => {
      totalAmt = totalAmt + data['ProductPrice'];
    });
    this.total= totalAmt;
  });
}


}

