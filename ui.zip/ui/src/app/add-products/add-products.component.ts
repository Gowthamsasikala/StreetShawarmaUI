import { Component, OnInit } from '@angular/core';
import { GetProductsService } from '../Service/get-products.service';
import { MatDialog } from '@angular/material/dialog';
import { SuccessPopupComponent } from '../success-popup/success-popup.component';

@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.component.html',
  styleUrls: ['./add-products.component.css']
})
export class AddProductsComponent implements OnInit {

  public productName:any;
  public productPrice:any;
  constructor(private addService:GetProductsService,public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  addProducts(){
    if(this.productName != undefined && this.productPrice != undefined && this.productName.length != 0 && this.productPrice.length != 0){
      const prod = {
          "productId": "",
          "productName": this.productName,
          "productPrice": this.productPrice
      }
      this.addService.addProduct(prod).subscribe(datas =>{
        console.log(datas);
        this.productName = '';
        this.productPrice = '';
  this.dialog.open(SuccessPopupComponent,{
    data : datas
  });
      })
    }else{
      console.log("No");
    }
  }

}
