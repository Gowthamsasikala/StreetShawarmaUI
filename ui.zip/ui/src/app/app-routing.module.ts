import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NavbarsComponent } from './navbars/navbars.component';
import { ViewProductsComponent } from './view-products/view-products.component';
import { AddProductsComponent } from './add-products/add-products.component';
import { PlaceOrderComponent } from './place-order/place-order.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';


const routes: Routes = [
  {path:"",component:NavbarsComponent,children:[
    {path:"Home",component:HomeComponent},
    {path:"view-products",component:ViewProductsComponent},
    {path:"add-products",component:AddProductsComponent},
    {path:"place-order",component:PlaceOrderComponent},
    {path:"summary",component:OrderSummaryComponent}
  ]},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
