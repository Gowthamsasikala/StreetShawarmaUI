import { Component, OnInit } from '@angular/core';
import { GetProductsService } from '../Service/get-products.service';
import {MatDialog} from '@angular/material/dialog';
import { EditProductsComponent } from '../edit-products/edit-products.component';
import { Location } from '@angular/common';
@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {

  public getAllProducts:any;
  constructor(private viewProdService:GetProductsService,private dialog:MatDialog,private _location: Location) { }

  ngOnInit(): void {
    this.viewProdService.getAllProducts().subscribe(data => {
      console.log(data);
      this.getAllProducts = data;
    })
  }

  editProducs(product:any){
    this.dialog.open(EditProductsComponent,{
      data: product
    });
  }

  back(){
    this._location.back();
  }
}
