import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { GetProductsService } from '../Service/get-products.service';
@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.css']
})
export class LineChartComponent implements OnInit {

  public orderByMonth = [];
  public getOrderData:any;
  constructor(private getOrdersBymonthService:GetProductsService) { }

  ngOnInit(): void {
    this.getOrdersBymonthService.getAllOrdersByMonth().subscribe(data =>{
      this.getOrderData = data;
      for(let datas of this.getOrderData){
        this.orderByMonth.push(datas);
      }
      console.log(this.orderByMonth);
    });
  }

  lineChartData: ChartDataSets[] = [
    { data: this.orderByMonth, label: 'Month wise Sale' },
  ];

  lineChartLabels: Label[] = ['January', 'February', 'March', 'April', 'May', 'June','July','August','September','October','November','December'];

  lineChartOptions = {
    responsive: true,
  };

  lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: 'orange',
    },
  ];

  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';

}
