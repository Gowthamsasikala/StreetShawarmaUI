import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GetProductsService } from '../Service/get-products.service';

@Component({
  selector: 'app-edit-products',
  templateUrl: './edit-products.component.html',
  styleUrls: ['./edit-products.component.css']
})
export class EditProductsComponent implements OnInit {

  public productName: any;
  public productPrice: any;
  public isSuccess:Boolean = true;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private updateService: GetProductsService) { }

  ngOnInit(): void {
    console.log(this.data);
    this.productName = this.data['productName'];
    this.productPrice = this.data['productPrice'];
  }

  updateProduct() {
    const prod = {
      "productId": this.data['productId'],
      "productName": this.productName,
      "productPrice": this.productPrice
    }
    this.updateService.updateProduct(prod).subscribe(datas => {
      console.log(datas);
      this.productName = datas['productName'];
      this.productPrice = datas['productPrice'];
      this.isSuccess = false;
    });
  }
}
