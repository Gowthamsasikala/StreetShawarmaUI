import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NavbarsComponent } from './navbars/navbars.component';
import { ViewProductsComponent } from './view-products/view-products.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatDialogModule} from '@angular/material/dialog';
import { EditProductsComponent } from './edit-products/edit-products.component';
import { FormsModule } from '@angular/forms';
import { AddProductsComponent } from './add-products/add-products.component';
import { SuccessPopupComponent } from './success-popup/success-popup.component';
import { PlaceOrderComponent } from './place-order/place-order.component';
import { FilterProductsPipe } from './filter-products.pipe';
import { SuccessOrderComponent } from './success-order/success-order.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatNativeDateModule } from '@angular/material/core';
import { OpenOrderItemsComponent } from './open-order-items/open-order-items.component';
import { LineChartComponent } from './line-chart/line-chart.component';
import { ChartsModule } from 'ng2-charts';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { DonutChartComponent } from './donut-chart/donut-chart.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NavbarsComponent,
    ViewProductsComponent,
    EditProductsComponent,
    AddProductsComponent,
    SuccessPopupComponent,
    PlaceOrderComponent,
    FilterProductsPipe,
    SuccessOrderComponent,
    OrderSummaryComponent,
    OpenOrderItemsComponent,
    LineChartComponent,
    BarChartComponent,
    DonutChartComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatDialogModule,
    FormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ChartsModule
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
