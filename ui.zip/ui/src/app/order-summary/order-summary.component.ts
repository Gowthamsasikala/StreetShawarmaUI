import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { MatDatepickerModule } from '@angular/material/datepicker';
// import * as _moment from 'moment';
import { GetProductsService } from '../Service/get-products.service';
import { MatDialog } from '@angular/material/dialog';
import { OpenOrderItemsComponent } from '../open-order-items/open-order-items.component';
import * as _moment from 'moment';
import { SuccessOrderComponent } from '../success-order/success-order.component';
const moment = (_moment as any).default ? (_moment as any).default : _moment;
@Component({
  selector: 'app-order-summary',
  templateUrl: './order-summary.component.html',
  styleUrls: ['./order-summary.component.css']
})
export class OrderSummaryComponent implements OnInit {

  public selectedDate: any;
  public orderList: any;
  public totalAmt: any;
  public orderSize: any = 0;
  constructor(private _location: Location, private getOrderService: GetProductsService, private dialog: MatDialog) { }

  ngOnInit(): void {
  }

  back() {
    this._location.back();
  }

  selectDate() {
    const format1 = "DD-MM-YYYY";
    const dateTime1 = moment(this.selectedDate).format(format1);
    this.getOrderService.getOrderSummaryByDate(dateTime1).subscribe(data => {
      this.orderList = data;
      this.orderList.sort(function (a, b) {
        return b.orderPlacedDate - a.orderPlacedDate;
      })
      this.orderSize = this.orderList.length;
      let tAmt = 0;
      for (let data of this.orderList) {
        tAmt = tAmt + parseInt(data['orderTotalAmt']);
      }
      this.totalAmt = tAmt;
    });
  }

  openOrderItems(order: any) {
    this.dialog.open(OpenOrderItemsComponent, {
      data: order
    });
  }


  deleteOrder(orderId) {
   this.getOrderService.deleteOrderById(orderId).subscribe(datas => {
     console.log(datas);
     if(datas['status'] == 'Success'){
      this.dialog.open(SuccessOrderComponent,{
        data: datas['responseMsg']
      });
      this.selectDate();
     }
   
   });
  }

}
